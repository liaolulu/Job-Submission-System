using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class zuoyexinxi_detail : System.Web.UI.Page
{
	public string nzuoyebianhao,nzuoyetimu,nkechengmingcheng,nzuoye,nzuoyejianjie,nid;
    protected void Page_Load(object sender, EventArgs e)
    {
   		nid = Request.QueryString["id"].ToString().Trim();
        if (!IsPostBack)
        {
            string sql;
            sql = "select * from zuoyexinxi where id=" + Request.QueryString["id"].ToString().Trim() ;
            getdata(sql);
        }
    }



    private void getdata(string sql)
    {
        DataSet result = new DataSet();
        result = new Class1().hsggetdata(sql);
        if (result != null)
        {
            if (result.Tables[0].Rows.Count > 0)
            {
                nzuoyebianhao = result.Tables[0].Rows[0]["zuoyebianhao"].ToString().Trim();nzuoyetimu = result.Tables[0].Rows[0]["zuoyetimu"].ToString().Trim();nkechengmingcheng = result.Tables[0].Rows[0]["kechengmingcheng"].ToString().Trim();nzuoye = result.Tables[0].Rows[0]["zuoye"].ToString().Trim();nzuoyejianjie = result.Tables[0].Rows[0]["zuoyejianjie"].ToString().Trim();
                
            }
        }
    }
    
}

