using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class shangchuanzuoye_add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if (!IsPostBack)
        {
			
			
			
            xuehao.Text = Session["username"].ToString().Trim();xuehao.ReadOnly = true;
			
			 
			
			  string sqllb = "select * from zuoyexinxi where id=" + Request.QueryString["id"].ToString().Trim();
			  DataSet resultlb = new DataSet();
			  resultlb = new Class1().hsggetdata(sqllb);
			  if (resultlb != null)
			  {
			    if (resultlb.Tables[0].Rows.Count > 0)
			     {
			        zuoyebianhao.Text = resultlb.Tables[0].Rows[0]["zuoyebianhao"].ToString().Trim();                    zuoyebianhao.ReadOnly = true;                    zuoyetimu.Text = resultlb.Tables[0].Rows[0]["zuoyetimu"].ToString().Trim();                    zuoyetimu.ReadOnly = true;                    kechengmingcheng.Text = resultlb.Tables[0].Rows[0]["kechengmingcheng"].ToString().Trim();                    kechengmingcheng.ReadOnly = true;                    
			     }
			  }
			
			  string sqlss = "select * from xueshengxinxi where xuehao='" + Session["username"].ToString().Trim()+"'";
              DataSet resultss = new DataSet();
              resultss = new Class1().hsggetdata(sqlss);
              if (resultss != null)
              {
                if (resultss.Tables[0].Rows.Count > 0)
                 {
                    xingming.Text = resultss.Tables[0].Rows[0]["xingming"].ToString().Trim();                    xingming.ReadOnly = true;                    

                 }
              }
           
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
		
        string sql;
		
		
		
		
		
        sql="insert into shangchuanzuoye(xuehao,xingming,zuoyebianhao,zuoyetimu,kechengmingcheng,zuoye,chengji) values('"+xuehao.Text.ToString().Trim()+"','"+xingming.Text.ToString().Trim()+"','"+zuoyebianhao.Text.ToString().Trim()+"','"+zuoyetimu.Text.ToString().Trim()+"','"+kechengmingcheng.Text.ToString().Trim()+"','"+zuoye.Text.ToString().Trim()+"','"+chengji.Text.ToString().Trim()+"') ";
        int result;
        result = new Class1().hsgexucute(sql);
        if (result == 1)
        {
            Response.Write("<script>javascript:alert('���ӳɹ�');</script>");
        }
        else
        {
            Response.Write("<script>javascript:alert('ϵͳ�����������ݿ���������');</script>");
        }
    }
	
	
	
	
	
	
	
	
	
	
	
}

